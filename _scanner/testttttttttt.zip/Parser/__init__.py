from Parser.grammar import init_grammar
